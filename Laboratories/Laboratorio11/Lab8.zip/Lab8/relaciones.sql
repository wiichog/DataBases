﻿SELECT DISTINCT fabricante, velocidad
FROM producto P, portatil P1
WHERE P.modelo_producto = P1.modelo_portatil AND P1.discoduro >= 100;

SELECT DISTINCT modelo_producto, pc.precio
FROM producto, pc
WHERE producto.fabricante = 'HP'
UNION 
SELECT DISTINCT modelo_producto, portatil.precio
FROM producto, portatil
WHERE producto.fabricante = 'HP'
UNION 
SELECT DISTINCT modelo_producto, impresora.precio
FROM producto, impresora
WHERE producto.fabricante = 'HP';


SELECT fabricante
FROM producto P, portatil P1
WHERE P.modelo_producto = P1.modelo_portatil
EXCEPT 
SELECT fabricante
FROM producto P, pc P2
WHERE P.modelo_producto = P2.modelo_pc;


SELECT discoduro
FROM pc AS T1
WHERE exists(SELECT DISCODURO FROM PC AS T2 WHERE T2.discoduro=T1.discoduro AND T2.modelo_pc<>T1.modelo_pc);